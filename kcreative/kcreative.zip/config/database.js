module.exports = {	
	mongodburl:'mongodb://localhost:27017/kaleidecreative'
}