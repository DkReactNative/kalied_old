module.exports= {
	secret: 'secretkey',
	/** Email Credentials Start **/
	  emailName : "Admin Panel",
	  emailEmail : "testingbydev@gmail.com",
	  emailPassword : "Dev@1234567",
	  /** Email Credentials End **/
	  siteTitle : "Admin Panel",

	  
	   // siteUrl : "http://localhost:4200/",
	   // //frontend admin url
	   // siteAdminUrl : "http://192.168.1.125:4200/admin/",
	   // serverUrl : "http://192.168.1.125:3000/",
	   
	   siteUrl : "https://devnode.devtechnosys.tech/kaleidecreative/",
	   siteAdminUrl : "https://devnode.devtechnosys.tech/kaleidecreative/admin/",
	   serverUrl : "https://devnode.devtechnosys.tech:17315/",
}