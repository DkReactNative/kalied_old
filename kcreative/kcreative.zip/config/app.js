module.exports = {
  secret: "secretkey",
  /** Email Credentials Start **/
  emailName: "Admin Panel",
  emailEmail: "testingbydev@gmail.com",
  emailPassword: "Hellouser@1234",
  /** Email Credentials End **/
  siteTitle: "Admin Panel",

  siteUrl: "http://localhost:4200/",
  //frontend admin url
  siteAdminUrl: "http://localhost:4200/admin/",
  serverUrl: "http://localhost:8080/",
  uploadUrl: "http://localhost:8080/public/uploads/",

  // siteUrl: "https://devnode.devtechnosys.tech/kaleidecreative/",
  // siteAdminUrl: "https://devnode.devtechnosys.tech/kaleidecreative/admin/",
  // serverUrl: "https://devnode.devtechnosys.tech:17315/",
  // uploadUrl: "https://devnode.devtechnosys.tech:17315/public/uploads/",

  //    siteUrl : "https://devnode.devtechnosys.tech/kaleidecreative/",
  //    siteAdminUrl : "https://devnode.devtechnosys.tech/kaleidecreative/admin/",
  //    serverUrl : "https://devnode.devtechnosys.tech:17315/",
  //    uploadUrl:"https://devnode.devtechnosys.tech:17315/public/uploads/"
};
